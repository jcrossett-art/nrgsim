var AuthRouter = Backbone.Router.extend({
  before: function(){},
  route: function(route, name, callback) {
    if (!_.isRegExp(route)) route = this._routeToRegExp(route);
    if (_.isFunction(name)) {
      callback = name;
      name = '';
    }
    if (!callback) callback = this[name];

    var router = this;
    Backbone.history.route(route, function(fragment) {
      var args = router._extractParameters(route, fragment);
      router.before.apply(router, [args, function() {
        if (callback) callback.apply(router, args);
        router.trigger.apply(router, ['route:' + name].concat(args));
        router.trigger('route', name, args);
        Backbone.history.trigger('route', router, name, args);
      }]);
    });
    return this;
  },

  routes: {
    "login": "login",
    "logout": "logout",
    "signup": "signup",
    "profile": "profile", 
    "sim": "sim",
    "*path": "home"
  },

  login: function() {
    if (window.app && window.app.views) {
      this.renderPage(window.app.views.LoginPage, {
        AuthenticationService: window.app.services.AuthenticationService
      });
    }
  },

  logout: function() {
    if (window.app && window.app.services) {
      window.app.services.AuthenticationService.logout(function() {
        window.location.replace('/');
      });
    }
  },

  signup: function() {
    if (window.app && window.app.models) {
      var user = new window.app.models.User();
      this.renderPage(window.app.views.UserPage, {
        'user': user,
        'signup': true,
        UserService: window.app.services.UserService
      });
    }
  },

  profile: function() {
    if (window.app && window.app.services) {
      var user = window.app.services.AuthenticationService.getLoggedInUser();
      this.renderPage(window.app.views.UserPage, {
        'user': user,
        'signup': false,
        UserService: window.app.services.UserService
      });
    }
  },

  home: function() {
    if (window.app && window.app.views) {
      this.renderPage(window.app.views.HomePage, {
        AuthenticationService: window.app.services.AuthenticationService
      });
    }
  },

  sim: function() {
    if (window.app && window.app.views) {
      this.renderPage(window.app.views.SimPage, {
        AuthenticationService: window.app.services.AuthenticationService
      });
    }
  },

  renderPage: function(PageClass, options) {
    if (PageClass) {
      var page = new PageClass(options);
      $("#view").empty().append(page.render().el);
      $("#view").i18n();
    }
  }
});

// Export router
window.AuthRouter = AuthRouter;

$(function() {
  if (window.app && window.app.router) {
    window.router = new window.AuthRouter();
    Backbone.history.start({pushState: false});
    $('body').i18n();
  }
});