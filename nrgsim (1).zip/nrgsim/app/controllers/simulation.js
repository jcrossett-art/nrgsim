/*jslint node: true */
"use strict";

const { models } = require('../../server').sequelize;
const os = require('os');
const pyShell = require('python-shell');
const fs = require('fs');

// Weather data constants (keeping the existing WEATHER_DATA object)
const WEATHER_DATA = {
  "WMO_1_Africa": {
    name: "Africa",
    values: [
      {
        "Algiers": {
          name: "Algiers",
        }
      },
      {
        "Egypt": {
          name: "Egypt",
        }
      },
      {
        "Ethiopia": {
          name: "Ethiopia",
        }
      },
      {
        "Ghana": {
          name: "Ghana",
        }
      },
      {
        "Kenya": {
          name: "Kenya",
        }
      },
      {
        "Libyan_Arab_Jamahiriya": {
          name: "Libyan Arab Jamahiriya",
        }
       },
      {
        "Morocco": {
          name: "Morocco",
        }
      },
      {
        "Madagascar": {
          name: "Madagascar",
        }
      },
      {
        "Senegal": {
          name: "Senegal",
        }
      },
      {
        "Tunisia": {
          name: "Tunisia",
        }
      },
      {
        "South_Africa": {
          name: "South Africa",
        }
      },
      {
        "Zimbabwe": {
          name: "Zimbabwe",
        }
      }
    ]
  },
  "WMO_2_Asia": {
    name: "Asia",
    values: [
      {
        "United_Arab_Emirates": {
          name: "United Arab Emirates",
        }
      },
      {
        "Bangladesh": {
          name: "Bangladesh",
        }
      },
      {
        "China": {
          name: "China",
        }
      },
      {
        "India": {
          name: "India",
        }
      },
      {
        "Iran_Islamic_Republic_of": {
          name: "Iran - Islamic Republic of",
        }
      },
      {
        "Japan": {
          name: "Japan",
        }
      },
      {
        "Kazakhstan": {
          name: "Kazakhstan",
        }
      },
      {
        "Korea_Republic_of": {
          name: "Korea - Republic of",
        }
      },
      {
        "Kuwait": {
          name: "Kuwait",
        }
      },
      {
        "Sri_Lanka": {
          name: "Sri Lanka",
        }
      },
      {
        "Macau": {
          name: "Macau",
        }
      },
      {
        "Maldives": {
          name: "Maldives",
        }
      },
      {
        "Mongolia": {
          name: "Mongolia",
        }
      },
      {
        "Nepal": {
          name: "Nepal",
        }
      },
      {
        "Pakistan": {
          name: "Pakistan",
        }
      },
      {
        "Korea_Democratic_People's_Republic_of": {
          name: "Korea - Democratic People's Republic of",
        }
      },
      {
        "Russian_Federation": {
          name: "Russian Federation",
        }
      },
      {
        "Saudi_Arabia": {
          name: "Saudi Arabia",
        }
      },
      {
        "Thailand": {
          name: "Thailand",
        }
      },
      {
        "Taiwan": {
          name: "Taiwan",
        }
      },
      {
        "Uzbekistan": {
          name: "Uzbekistan",
        }
      },
      {
        "Viet_Nam": {
          name: "Viet Nam",
        }
      },
    ]
  },
  "WMO_3_South_America": {
    name: "South America",
    values: [
      {
        "Argentina": {
          name: "Argentina",
        }
      },
      {
        "Bolivia": {
          name: "Bolivia",
        }
      },
      {
        "Brazil": {
          name: "Brazil",
        }
      },
      {
        "Chile": {
          name: "Chile",
        }
      },
      {
        "Colombia": {
          name: "Colombia",
        }
      },
      {
        "Ecuador": {
          name: "Ecuador",
        }
      },
      {
        "Peru": {
          name: "Peru",
        }
      },
      {
        "Paraguay": {
          name: "Paraguay",
        }
      },
      {
        "Uruguay": {
          name: "Uruguay",
        }
      },
      {
        "Venezuela": {
          name: "Venezuela",
        }
      },
    ]
  },
  "WMO_4_North_And_Central_America": {
    name: "North and Central America",
    values: [
      {
        "United_States": {
          name: "United States",
        }
      },
      {
        "California_Climate_Zones": {
          name: "California Climate Zones",
        }
      },
      {
        "Canada": {
          name: "Canada",
        }
      },
      {
        "Belize": {
          name: "Belize",
        }
      },
      {
        "Cuba": {
          name: "Cuba",
        }
      },
      {
        "Guatemala": {
          name: "Guatemala",
        }
      },
      {
        "Honduras": {
          name: "Honduras",
        }
      },
      {
        "Mexico": {
          name: "Mexico",
        }
      },
      {
        "Martinique": {
          name: "Martinique",
        }
      },
      {
        "Nicaragua": {
          name: "Nicaragua",
        }
      },
      {
        "Puerto_Rico": {
          name: "Puerto Rico",
        }
      },
      {
        "El_Salvador": {
          name: "El Salvador",
        }
      },
      {
        "Virgin_Islands": {
          name: "Virgin Islands (U.S.)",
        }
      },
    ]
  },
  "WMO_5_Southwest_Pacific": {
    name: "Southwest Pacific",
    values: [
      {
        "Australia": {
          name: "Australia",
        }
      },
      {
        "Brunei_Darussalam": {
          name: "Brunei Darussalam",
        }
      },
      {
        "Fiji": {
          name: "Fiji",
        }
      },
      {
        "Guam": {
          name: "Guam",
        }
      },
      {
        "Marshall_Islands": {
          name: "Marshall Islands",
        }
      },
      {
        "Malaysia": {
          name: "Malaysia",
        }
      },
      {
        "New_Zealand": {
          name: "New Zealand",
        }
      },
      {
        "Philippines": {
          name: "Philippines",
        }
      },
      {
        "Palau": {
          name: "Palau",
        }
      },
      {
        "Singapore": {
          name: "Singapore",
        }
      },
      {
        "United_States_Minor_Outlying_Islands": {
          name: "United States Minor Outlying Islands",
        }
      },
    ]
  },
  "WMO_6_Europe": {
    name: "Europe",
    values: [
      {
        "Austria": {
          name: "Austria",
        }
      },
      {
        "Belgium": {
          name: "Belgium",
        }
      },
      {
        "Bulgaria": {
          name: "Bulgaria",
        }
      },
      {
        "Bosnia_and_Herzegowina": {
          name: "Bosnia and Herzegowina",
        }
      },
      {
        "Belarus": {
          name: "Belarus",
        }
      },
      {
        "Cyprus": {
          name: "Cyprus",
        }
      },
      {
        "Czech_Republic": {
          name: "Czech Republic",
        }
      },
      {
        "Germany": {
          name: "Germany",
        }
      },
      {
        "Denmark": {
          name: "Denmark",
        }
      },
      {
        "Spain": {
          name: "Spain",
        }
      },
      {
        "Finland": {
          name: "Finland",
        }
      },
      {
        "France": {
          name: "France",
        }
      },
      {
        "United_Kingdom": {
          name: "United Kingdom",
        }
      },
      {
        "Greece": {
          name: "Greece",
        }
      },
      {
        "Hungary": {
          name: "Hungary",
        }
      },
      {
        "Ireland": {
          name: "Ireland",
        }
      },
      {
        "Iceland": {
          name: "Iceland",
        }
      },
      {
        "Israel": {
          name: "Israel",
        }
      },
      {
        "Italy": {
          name: "Italy",
        }
      },
      {
        "Lithuania": {
          name: "Lithuania",
        }
      },
      {
        "Netherlands": {
          name: "Netherlands",
        }
      },
      {
        "Norway": {
          name: "Norway",
        }
      },
      {
        "Poland": {
          name: "Poland",
        }
      },
      {
        "Portugal": {
          name: "Portugal",
        }
      },
      {
        "Romania": {
          name: "Romania",
        }
      },
      {
        "Russian_Federation": {
          name: "Russian Federation",
        }
      },
      {
        "Serbia": {
          name: "Serbia",
        }
      },
      {
        "Slovakia_Slovak_Republic": {
          name: "Slovakia (Slovak Republic)",
        }
      },
      {
        "Slovenia": {
          name: "Slovenia",
        }
      },
      {
        "Sweden": {
          name: "Sweden",
        }
      },
      {
        "Switzerland": {
          name: "Switzerland",
        }
      },
      {
        "Syrian_Arab_Republic": {
          name: "Syrian Arab Republic",
        }
      },
      {
        "Turkey": {
          name: "Turkey",
        }
      },
      {
        "Ukraine": {
          name: "Ukraine",
        }
      },
    ]
  }
};

var zone = {
  zone:
    [
      { BuildingSurface:
        { name: "Floor", type: "Floor",
          vertices: [
            { x: 3.4909079445, y: 0.0164379644, z: 0 },
            { x: 0.0099079445, y: 0.0164379644, z: 0 },
            { x: 0.0099079445, y: 3.4974379644, z: 0 },
            { x: 3.4909079445, y: 3.4974379644, z: 0}
          ]
        },
      },
      { BuildingSurface:
        { name: "Ceiling", type: "Ceiling",
          vertices: [
            { x: 0.0099079445, y: 0.0164379644, z: 3.501 },
            { x: 3.4909079445, y: 0.0164379644, z: 3.501 },
            { x: 3.4909079445, y: 3.4974379644, z: 3.501 },
            { x: 0.0099079445, y: 3.4974379644, z: 3.501 }
          ]
        }
      },
      { BuildingSurface:
        { name: "EastWall", type: "Wall",
          vertices: [
            { x: 3.4909079445, y: 0.0164379644, z: 0 },
            { x: 3.4909079445, y: 3.4974379644, z: 0 },
            { x: 3.4909079445, y: 3.4974379644, z: 3.501 },
            { x: 3.4909079445, y: 0.0164379644, z: 3.501 }
          ]
        },
      },
      { BuildingSurface:
        { name: "NorthWall", type: "Wall",
          vertices: [
            { x: 3.4909079445, y: 3.4974379644, z: 0 },
            { x: 0.0099079445, y: 3.4974379644, z: 0 },
            { x: 0.0099079445, y: 3.4974379644, z: 3.501 },
            { x: 3.4909079445, y: 3.4974379644, z: 3.501 }
          ]
        },
      },
      { BuildingSurface:
        { name: "WestWall", type: "Wall",
           vertices: [
            { x: 0.0099079445, y: 3.4974379644, z: 0 },
            { x: 0.0099079445, y: 0.0164379644, z: 0 },
            { x: 0.0099079445, y: 0.0164379644, z: 3.501 },
            { x: 0.0099079445, y: 3.4974379644, z: 3.501 }
          ]
        }
      },
      { BuildingSurface:
        { name: "SouthWall", type: "Wall",
          vertices: [
            { x: 0.0099079445, y: 0.0164379644, z: 0 },
            { x: 3.4909079445, y: 0.0164379644, z: 0 },
            { x: 3.4909079445, y: 0.0164379644, z: 3.501 },
            { x: 0.0099079445, y: 0.0164379644, z: 3.501 }
          ]
        },
      },
      { FenestrationSurface:
        { name: "EastWindow", type: "Window",
           vertices: [
            { x: 3.4909079445, y: 0.07143796, z: 1.04 },
            { x: 3.4909079445, y: 3.44243796, z: 1.04 },
            { x: 3.4909079445, y: 3.44243796, z: 2.3715738626 },
            { x: 3.4909079445, y: 0.07143796, z: 2.3715738626 }
          ]
        }
      }
    ]
};

exports.load = function(req, res) {
  console.log('simulation.load: ' + req.params.id);
  res.json({ "status": 0, "data": zone});
};

exports.run = async function(req, res) {
  try {
    const simulation = await models.Simulation.create({
      userInput: req.body,
      finished: false
    });

    const jobId = simulation.id;
    const options = {
      scriptPath: 'scripts',
      args: [jobId, JSON.stringify(req.body)]
    };

    if (os.platform() === 'linux') {
      options.pythonPath = '/usr/bin/python3';
    }

    pyShell.run('runsimulation.py', options, async function(err, results) {
      if (err) {
        console.log("Error running python script: " + err);
        return;
      }

      const resultsDir = results[results.length-2];
      const resultsFile = results[results.length-1];

      await simulation.update({
        resultsDirectory: resultsDir,
        resultsFile: resultsFile,
        finished: true
      });
    });

    res.json({ "status": 0, jobId: simulation.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.checkForResults = async function(req, res) {
  try {
    const simulation = await models.Simulation.findByPk(req.params.jobId);

    if (!simulation) {
      return res.status(400).json({ 
        error: "simulation " + req.params.jobId + " not found" 
      });
    }

    if (simulation.finished) {
      res.status(200).sendfile(simulation.resultsFile);
    } else {
      res.status(203).json({ 
        jobId: simulation.id, 
        finished: false 
      });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getCountries = function(req, res) {
  const continent = req.params.continent;
  res.json(WEATHER_DATA[continent]);
};

exports.getWeatherFiles = function(req, res) {
  const continent = req.params.continent;
  const country = req.params.country;
  const weatherDir = process.cwd()+'/../weather/'+continent+'/'+country;

  fs.readdir(weatherDir, function(err, files) {
    if (!err) {
      res.json(files);
    } else {
      console.log("Failed to get weather files for " + continent + ' ' + country + ': ' + err.message);
    }
  });
};