
const { Sequelize } = require('sequelize');

const sequelize = new Sequelize(process.env.DATABASE_URL || 'postgresql://postgres:postgres@0.0.0.0:5432/nrgsim', {
  dialect: 'postgres',
  dialectOptions: {
    ssl: {
      require: true,
      rejectUnauthorized: false
    }
  },
  logging: false
});

const User = require('../app/models/user')(sequelize);
const Simulation = require('../app/models/simulation')(sequelize);

module.exports = { sequelize, models: sequelize.models };
