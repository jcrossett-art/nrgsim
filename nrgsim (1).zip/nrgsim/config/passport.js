
const LocalStrategy = require('passport-local').Strategy;
const { models } = require('../models');

module.exports = function (passport, config) {
  // User serialization/deserialization for session
  passport.serializeUser(function (user, done) {
    done(null, user.id);
  });

  passport.deserializeUser(async function (id, done) {
    try {
      const user = await models.User.findByPk(id);
      done(null, user);
    } catch (err) {
      done(err, null);
    }
  });

  // Local login
  passport.use(new LocalStrategy({
    usernameField: 'email',
    passwordField: 'password'
  }, async function (email, password, done) {
    try {
      const user = await models.User.findOne({ where: { email: email }});
      if (!user) {
        return done(null, false, { message: 'Unknown user' });
      }
      if (!user.authenticate(password)) {
        return done(null, false, { message: 'Invalid password' });
      }
      return done(null, user);
    } catch (err) {
      return done(err);
    }
  }));
};
