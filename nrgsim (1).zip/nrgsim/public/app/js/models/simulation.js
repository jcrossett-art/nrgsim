window.app.models.Simulation = Backbone.Model.extend({

  defaults: {
    // TODO: figure what we need in here
    data: []
  }
  
});
