/*jslint node: true */
"use strict";

const express = require('express');
const path = require('path');
const flash = require('connect-flash');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const cookieSession = require('cookie-session');
const compression = require('compression');
const morgan = require('morgan');
const pgSession = require('connect-pg-simple')(require('express-session'));

module.exports = function (app, config, i18n, passport) {
  app.use(morgan('dev'));
  app.use(compression());
  app.use(express.static(path.join(process.cwd(), 'public')));
  app.use('/vendor', express.static(path.join(process.cwd(), 'public/vendor')));
  app.use('/app', express.static(path.join(process.cwd(), 'public/app')));
  app.use(cookieParser());
  app.use(bodyParser.json());
  app.use(bodyParser.urlencoded({ extended: true }));

  app.use(require('express-session')({
    store: new pgSession({
      conObject: {
        connectionString: config.db,
        ssl: { rejectUnauthorized: false }
      }
    }),
    secret: 'nrgsim_app',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 30 * 24 * 60 * 60 * 1000 }
  }));

  app.use(flash());
  app.use(passport.initialize());
  app.use(passport.session());

  app.use(function(err, req, res, next) {
    console.error(err.stack);
    res.status(500).json({'err': 'internal server error'});
  });
};