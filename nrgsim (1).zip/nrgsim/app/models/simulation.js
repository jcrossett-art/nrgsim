
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Simulation = sequelize.define('Simulation', {
    userInput: {
      type: DataTypes.JSONB,
      allowNull: false
    },
    resultsDirectory: DataTypes.STRING,
    resultsFile: DataTypes.STRING,
    finished: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    }
  }, {
    timestamps: true
  });

  return Simulation;
};
