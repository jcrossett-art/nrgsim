const { DataTypes } = require('sequelize');
const crypto = require('crypto');

module.exports = (sequelize) => {
  const User = sequelize.define('User', {
    name: DataTypes.STRING,
    email: DataTypes.STRING,
    provider: DataTypes.STRING,
    hashed_password: DataTypes.STRING,
    salt: DataTypes.STRING,
    roles: {
      type: DataTypes.ARRAY(DataTypes.STRING),
      defaultValue: []
    }
  }, {
    timestamps: true
  });

  // Instance methods
  User.prototype.makeSalt = function() {
    return crypto.randomBytes(16).toString('base64');
  };

  User.prototype.encryptPassword = function(password) {
    if (!password || !this.salt) return '';
    var salt = Buffer.from(this.salt, 'base64');
    return crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('base64');
  };

  User.prototype.authenticate = function(password) {
    return this.encryptPassword(password) === this.hashed_password;
  };

  return User;
};