
const { models } = require('../../server').sequelize;
const passport = require('passport');

exports.passport = function (req, res) {};

exports.authenticate = function(req, res, next) {
  passport.authenticate('local', function(err, user, info) {
    if (err || !user) {
      res.status(500).json({ message: req.i18n.t("error.loginFailed") });
    } else {
      res.status(200).json(user);
    }
  })(req, res, next);
};

exports.endSession = function(req, res) {
  req.logout();
  res.status(200).json({ message: req.i18n.t("message.logoutSucceeded") });
};

exports.authCallback = function (req, res, next) {
  res.redirect('/');
};

exports.login = function (req, res) {
  res.render('user/#login');
};

exports.logout = function (req, res) {
  req.logout();
  res.redirect('/#login');
};

exports.signup = function (req, res) {
  res.render('user/#signup');
};

exports.create = async function (req, res, next) {
  try {
    const user = await models.User.create({
      ...req.body,
      provider: 'local'
    });
    res.status(200).json({ 
      message: req.i18n.t("message.userCreated"), 
      user: user.toJSON() 
    });
  } catch (err) {
    res.status(500).json({ message: [err.message] });
  }
};

exports.update = async function(req, res) {
  try {
    const user = await models.User.findByPk(req.body._id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    const updateData = {
      name: req.body.name,
      email: req.body.email,
      roles: req.body.roles
    };
    
    if (req.body.password && req.body.password.length > 0) {
      updateData.password = req.body.password;
    }
    
    await user.update(updateData);
    res.status(200).json({ 
      message: req.i18n.t("message.userUpdated"), 
      user: user.toJSON() 
    });
  } catch (err) {
    res.status(500).json({ messages: [err.message] });
  }
};
