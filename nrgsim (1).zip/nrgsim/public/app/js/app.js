// Initialize app namespace
window.app = {
  views: {},
  models: {},
  services: {},
  router: null
};

// Initialize models
window.app.models.User = Backbone.Model.extend({});
window.app.models.Simulation = Backbone.Model.extend({});

// Initialize services
window.app.services.AuthenticationService = {
  getLoggedInUser: function() { return null; },
  logout: function(callback) { if (callback) callback(); }
};

window.app.services.UserService = {
  save: function(user, callback) { if (callback) callback(); }
};

// Initialize views
window.app.views.HomePage = Backbone.View.extend({
  el: "#view",
  initialize: function(options) {
    _.bindAll(this);
  },
  render: function() {
    this.$el.html($('#home-template').html());
    return this;
  }
});

window.app.views.LoginPage = Backbone.View.extend({
  el: "#view",
  initialize: function(options) {
    _.bindAll(this);
  },
  render: function() {
    this.$el.html($('#login-template').html());
    return this;
  }
});

window.app.views.UserPage = Backbone.View.extend({
  el: "#view",
  initialize: function(options) {
    _.bindAll(this);
  },
  render: function() {
    this.$el.html($('#user-template').html());
    return this;
  }
});

window.app.views.SimPage = Backbone.View.extend({
  el: "#view",
  initialize: function(options) {
    _.bindAll(this);
  },
  render: function() {
    this.$el.html($('#sim-template').html());
    return this;
  }
});

// Router definition (Original Router, potentially renamed)
var AppRouter = Backbone.Router.extend({
  routes: {
    "login": "login",
    "logout": "logout",
    "signup": "signup",
    "profile": "profile",
    "sim": "sim",
    "*path": "home"
  },

  login: function() {
    this.renderPage(window.app.views.LoginPage);
  },

  logout: function() {
    window.app.services.AuthenticationService.logout(function() {
      window.location.replace('/');
    });
  },

  signup: function() {
    var user = new window.app.models.User();
    this.renderPage(window.app.views.UserPage, {user: user, signup: true});
  },

  profile: function() {
    var user = window.app.services.AuthenticationService.getLoggedInUser();
    this.renderPage(window.app.views.UserPage, {user: user, signup: false});
  },

  home: function() {
    this.renderPage(window.app.views.HomePage);
  },

  sim: function() {
    this.renderPage(window.app.views.SimPage);
  },

  renderPage: function(PageClass, options) {
    var page = new PageClass(options || {});
    $("#view").empty().append(page.render().el);
    $("#view").i18n();
  }
});


// Assuming AuthRouter is a different router (needs definition elsewhere)
//  If not defined elsewhere, replace AuthRouter with AppRouter below.

// Wait for document ready
$(function() {
  // Initialize i18n
  $.i18n().load({
    'en-US': '/i18n/en-US.json'
  }).done(function() {
    // Initialize router
    window.app.router = new AppRouter(); // Using the original Router here.
    Backbone.history.start({pushState: false});
    window.app.router.navigate('', {trigger: true});
    $('body').i18n();
  });
});